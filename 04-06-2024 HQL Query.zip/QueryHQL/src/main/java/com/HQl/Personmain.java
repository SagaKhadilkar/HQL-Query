package com.HQl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Personmain {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Person.class);

		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction tr = session.beginTransaction();
	//	select * from Person
//		Query query = session.createQuery("from Person");
//		List<Person> plist = query.list();
//		for (Person p : plist) {
//			System.out.println(p);
//		}
//		tr.commit();
//		session.close();
//		System.out.println("Done....");
		
		
		
		
		// select pname from person
//		Query query = session.createQuery("select pname from Person");
//
//		List<String> plist = query.list();
//		for(String p :plist) {
//			System.out.println(p);
//		}
//		tr.commit();
//		session.close();	
//		System.out.println("Done...");
		
		//select * from person where city= "pune"
//		Query query = session.createQuery("from Person where city=:c");
//	    query.setParameter("c","pune");
//	    List<Person> clist = query.list();
//	    for(Person c :clist) {
//	    	System.out.println(c);
//	    }
//	    tr.commit();
//	    session.close();
//	    
//	    System.out.println("Done...");
	    
		
		//select * from Person where city="pune" and salary>=25000;
		Query query= session.createQuery("from Person where city=:c and salary>=:d");
		query.setParameter("c","Pune");
		query.setParameter("d",35000);
		List<Person> clist = query.list();
		for(Person c:clist) {
			System.out.println(c);
		}
		tr.commit();
		session.close();
		System.out.println("Done...");
		
	}
}
